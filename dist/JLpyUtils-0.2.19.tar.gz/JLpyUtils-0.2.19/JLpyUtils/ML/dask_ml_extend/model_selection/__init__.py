"""
This sub-module contains functions to run model_selection routines on dask dataframes
"""

#from . import _search
from ._search import GridSearchCV
