"""
Functions related to multiple model dictionaries (models_dict)
"""

import sys, os
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0,  os.path.dirname(os.path.abspath(__file__)))
    
    
import JL_ML_fetch_models_dict as fetch


